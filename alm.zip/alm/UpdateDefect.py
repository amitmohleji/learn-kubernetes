#
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
# FOR A PARTICULAR PURPOSE. THIS CODE AND INFORMATION ARE NOT SUPPORTED BY XEBIALABS.
#
from alm.almClientUtil import almClientUtil
import json, ast
cookies = ast.literal_eval(cookies)
alm_client = almClientUtil.create_alm_client(server, cookies = cookies)
content = '''
{"comment": "%s" 
  %s
  %s
  %s}

''' % (comment,
 ",\"name\" : \"" + title + "\"" if title else "",
 ",\"description\" : \"" + description + "\"" if description else "",
 ",\"status\" : \"" + status + "\"" if status else "")
result = alm_client.update_defect(domain, project, defectId, content)
output = json.dumps(result)
defectId = result['id']
print "Successfully able to update defect Id [ %s ]" % defectId
