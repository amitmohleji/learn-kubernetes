#
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
# FOR A PARTICULAR PURPOSE. THIS CODE AND INFORMATION ARE NOT SUPPORTED BY XEBIALABS.
#
from alm.almClientUtil import almClientUtil
import json, ast
cookies = ast.literal_eval(cookies)
alm_client = almClientUtil.create_alm_client(server, cookies = cookies)
content = '''
{
    "data": [
        {
            "type": "defect",
            "name": "%s",
            "description": "%s",
            "priority": "%s",
            "detected-by": "xl-release",
            "severity": "%s"
        }
    ]
}
''' % (title, description, priority, severity)
result = alm_client.create_defect(domain, project, content)
defectId = result['id']
output = json.dumps(result)
print "Successfully able to create Defect with Id [ %s ] " % result['id'] 
