#
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
# FOR A PARTICULAR PURPOSE. THIS CODE AND INFORMATION ARE NOT SUPPORTED BY XEBIALABS.
#
from alm.almClientUtil import almClientUtil
import json, ast
cookies = ast.literal_eval(cookies)
alm_client = almClientUtil.create_alm_client(server, cookies = cookies)
data = None
logger.info("print initial query")
logger.info(query)
while True:
	time.sleep(int(sleepInterval))
	data = alm_client.query_status(domain, project, query)
	print json.dumps(data)
print "Successfully able to update defect Id [ %s ]" % defectId
