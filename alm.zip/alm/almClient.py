#
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
# FOR A PARTICULAR PURPOSE. THIS CODE AND INFORMATION ARE NOT SUPPORTED BY XEBIALABS.
#
import json, urllib
from alm.HttpClient import HttpClient

class almClient(object):
    def __init__(self, http_connection, username=None, password=None, authheaders= {}, cookies = {}):
        self.http_request = HttpClient(http_connection, username , password, authheaders, cookies) # Should not have to pass the empty P/W string, will work on fix.

    @staticmethod
    def create_client(http_connection, username=None, password=None, authheaders= {}, cookies = {}):
        return almClient(http_connection, username, password, authheaders, cookies)

    def check_connection(self):
        api_url = "/qcbin"
        return self.http_request.get(api_url)

    def login(self):
        api_url = "/qcbin/api/authentication/sign-in"
        api_response = self.http_request.post(api_url, headers={"contentType":"application/json"})
        return api_response.cookies

    def logout(self):
        api_url = "/qcbin/api/authentication/sign-out"
        api_response = self.http_request.get(api_url, headers={"contentType":"application/json"})
        return api_response
    def create_defect(self, domain, project, content):
        api_url = "/qcbin/api/domains/%s/projects/%s/defects" % (domain, project)
        api_response = self.http_request.post(api_url, headers={"contentType":"application/json", "Accept":"application/json"}, content = content)
        return api_response.json()
    def update_defect(self, domain, project, defid, content):
        api_url = "/qcbin/api/domains/%s/projects/%s/defects/%s" % (domain, project, defid)
        api_response = self.http_request.put(api_url, headers={"contentType":"application/json", "Accept":"application/json"}, content = content)
        return api_response.json()
    def read_defect(self, domain, project, defid):
        api_url = "/qcbin/api/domains/%s/projects/%s/defects/%s" % (domain, project, defid)
        api_response = self.http_request.get(api_url, headers={"contentType":"application/json", "Accept":"application/json"})
        return api_response.json()
    def delete_defect(self, domain, project, defid):
        api_url = "/qcbin/api/domains/%s/projects/%s/defects/%s" % (domain, project, defid)
        api_response = self.http_request.delete(api_url, headers={"contentType":"text/plain", "Accept":"application/json"})
        return api_response.json()
    def query_status(self, domain, project, resource, query):
        logger.info("print encoded query")
        logger.info(urllib.urlencode(query))
        api_url = "/qcbin/api/domains/%s/projects/%s/%s?query=%s" % (domain, project, resource, urllib.urlencode(query))
        api_response = self.http_request.get(api_url, headers={"contentType":"application/json", "Accept":"application/json"})
        return api_response.json()

